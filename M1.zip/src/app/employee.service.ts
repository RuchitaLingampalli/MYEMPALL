import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  http: HttpClient;
  fetch: boolean = false;
  empl : Employee[] = [];
  constructor(http: HttpClient) {
    this.http = http;
   }

   fetchData(){
     this.http.get('./assets/employee.json').subscribe(
       data =>{
         if(!this.fetch){
           this.convert(data);
           this.fetch = true;
         }
       }
     )
   }
   convert(data: any){
     for(let emp of data["Employee"]){
       let e = new Employee(emp.id, emp.name, emp.Salary);
       this.empl.push(e);
     }
   }
   getData(): Employee[]{
    return this.empl;
   }

   addData(e : any){
    this.empl.push(e);
    }



    updatedata(d:Employee){
      let eid=d.id;
      for(let i=0;i<this.empl.length;i++){
        if(eid==this.empl[i].id){
          this.empl[i].id=d.id;
          this.empl[i].name=d.name;
          this.empl[i].Salary=d.Salary;
        }
      }

    }
    
    employees:Employee[];
    searchdata(data):Employee[] {
      this.employees=[];
for(let e of this.empl){
  if(e.id==data.id){
    this.employees.push(e);
  }
}
return this.employees;
    }
}

export class Employee{
  static COLUMNS=['id','name','Salary'];
  id: number;
  name: string;
  Salary: number;
  constructor(id:number,name:string, Salary:number){
    this.id = id;
    this.name = name;
    this.Salary = Salary;
  }
}