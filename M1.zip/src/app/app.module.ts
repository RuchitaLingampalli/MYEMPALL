import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { HttpClient,HttpClientModule } from '@angular/common/http';
import { EmployeeService} from './employee.service'
import { AddempComponent } from './addemp/addemp.component';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { ShowempComponent } from './showemp/showemp.component';

import { SearchempComponent } from './searchemp/searchemp.component';
import { OrderBy } from './orderby';

@NgModule({
  declarations: [
    AppComponent,
    AddempComponent,
    ShowempComponent,
    
    SearchempComponent,
    OrderBy
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
