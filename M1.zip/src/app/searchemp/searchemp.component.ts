import { Component, OnInit } from '@angular/core';
import { EmployeeService, Employee } from '../employee.service';

@Component({
  selector: 'app-searchemp',
  templateUrl: './searchemp.component.html',
  styleUrls: ['./searchemp.component.css']
})
export class SearchempComponent implements OnInit {
employee:EmployeeService;
empl:Employee[];
  constructor(employee:EmployeeService) { 
  this.employee=employee;
  }
  
  ngOnInit() {
  }
  search(data){
    this.empl=this.employee.searchdata(data);
  }
}
